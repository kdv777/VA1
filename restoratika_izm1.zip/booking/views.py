from django.shortcuts import render
# импорт стандартных дженериков-представлений из Джанго
from django.views.generic import ListView, DetailView, CreateView

# импорт нашей модели
from .models import Application
# импорт нашей формы
from .forms import ApplicationForm


# Представление для отображения списком всех заявок
class ApplicationsList(ListView):
    # используемая модель
    model = Application
    # сортировка списка по полю в порядке от новых к старым
    ordering = '-created_at'
    # имя шаблона, в соответствии с которым информация будет отображаться на странице
    template_name = 'booking/apps.html'
    # контекстное имя объекта для использования в шаблоне
    context_object_name = 'apps'
    # максимальное количество записей, выводимых на одной странице
    paginate_by = 10


# Представление для подробного просмотра заявки
class ApplicationDetail(DetailView):
    # используемая модель
    model = Application
    # имя шаблона, в соответствии с которым информация будет отображаться на странице
    template_name = 'booking/app.html'
    # контекстное имя объекта для использования в шаблоне
    context_object_name = 'app'


# Представление для ввода данных в форму
class ApplicationCreate(CreateView):
    # используемая форма
    form_class = ApplicationForm
    # используемая модель
    model = Application
    # имя шаблона, в соответствии с которым информация будет отображаться на странице
    template_name = 'booking/app_create.html'

    # метод валидации данных в форме, будет использоваться позднее для отправления уведомлений о новых заявках
    # def form_valid(self, form):
    #     app = form.save(commit=False)
    #
    #     # вызываем метод super, чтобы у заявки появился pk
    #     result = super().form_valid(form)
    #     app_add_notification.delay(app.pk)
    #     return result


# Представление-заглушка для стартовой страницы
def startpage(request):
    return render(request, "index.html")
