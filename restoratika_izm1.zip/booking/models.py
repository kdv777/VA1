# импорт модуля для использования типа UUID4 для некоторых первичных ключей
import uuid

from django.urls import reverse
# импорт стандартных моделей
from django.db import models
# импорт валидаторов
from django.core.validators import MinValueValidator, MaxValueValidator, EmailValidator

# возможные значения поля status в таблице Application
STATUSES = [
    ('NEW', 'Новая'),
    ('VAL', 'Проверяется'),
    ('CNF', 'Подтверждена'),
    ('CAN', 'Отменена'),
    ('FIN', 'Завершена'),
]

# возможные значения поля number_persons в таблице Application, не используется!
# GUESTS = [
#     1,
#     2,
#     3,
#     4,
#     5,
#     6,
#     7,
#     8,
#     9,
#     10,
# ]


# Модель для связи приложения с таблицей Hall базы данных
# class Hall(models.Model):
#     # поля таблицы, поле id создается автоматически, его указывать не нужно
#     name = models.CharField(max_length=32, unique=True)
#     description = models.CharField(max_length=255, blank=True)
#
#     # указываем, как будет отображаться название на странице
#     def __str__(self):
#         return self.name.title()


# Модель для связи приложения с таблицей Table базы данных
# class Table(models.Model):
#     # поля таблицы, поле id создается автоматически, его указывать не нужно
#     number = models.CharField(max_length=10)
#     description = models.CharField(max_length=128, blank=True)
#     is_available = models.BooleanField(default=True)
#     hall = models.ForeignKey(Hall, on_delete=models.CASCADE)
#
#     # указываем, как будет отображаться номер на странице
#     def __str__(self):
#         return self.number


# Модель для связи приложения с таблицей Client базы данных, пока не используется
# class Client(models.Model):
#     # поля таблицы, переопределяем тип поля id
#     id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
#     name = models.CharField(max_length=64)
#     phone = models.CharField(max_length=12)
#     email = models.CharField(max_length=32, validators=[EmailValidator])
#     telegram = models.CharField(max_length=32, blank=True)
#     whatsup = models.CharField(max_length=12, blank=True)
#
#     # указываем, как будет отображаться имя на странице
#     def __str__(self):
#         return self.name.title()


# Модель для связи приложения с таблицей Application базы данных
class Application(models.Model):
    # поля таблицы, переопределяем тип поля id
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    created_at = models.DateTimeField(auto_now_add=True)
    number_persons = models.IntegerField(default=2, validators=[MinValueValidator(1), MaxValueValidator(999)])
    date = models.DateField()
    # time = models.CharField(max_length=5)
    time = models.TimeField()
    status = models.CharField(max_length=3, choices=STATUSES, default='NEW')
    comment = models.CharField(max_length=128, blank=True)
    # table = models.ForeignKey(Table, on_delete=models.CASCADE)
    # hall = models.ForeignKey(Hall, on_delete=models.CASCADE)

    # client = models.ForeignKey(Client, on_delete=models.CASCADE)
    client_name = models.CharField(max_length=64)
    client_phone = models.CharField(max_length=12)
    client_email = models.EmailField(max_length=32, validators=[EmailValidator])

    # функция reverse позволяет нам указывать не путь вида /booking/…, а название пути, которое мы задали в файле urls.py
    # для аргумента name
    def get_absolute_url(self):
        return reverse('app_detail', args=[str(self.id)])
