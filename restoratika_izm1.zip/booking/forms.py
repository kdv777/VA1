#импорт модуля даты и времени
from datetime import datetime
# импорт стандартных форм Джанго
from django import forms
#импорт ошибки валидации из исключений
from django.core.exceptions import ValidationError
# импорт поля ввода даты
from django.forms import DateInput, TimeInput, EmailInput
# импорт метода для локализации полей формы
from django.utils.translation import gettext_lazy as _

# импорт нашей модели
from .models import Application

# форма для ввода данных о бронировании
class ApplicationForm(forms.ModelForm):
    # поля с проверками минимальной длины, виджетом выбора даты, времени и описанием для отображения в форме
    client_phone = forms.CharField(min_length=11, max_length=12, label='Номер телефона')
    date = forms.DateField(widget=DateInput(attrs={'type': 'date'}), label='Дата')
    time = forms.TimeField(widget=TimeInput(attrs={'type': 'time'}), label='Время')
    client_email = forms.EmailField(widget=EmailInput(attrs={'type': 'email'}), label='Электронная почта')

    class Meta:
        # наша модель
        model = Application
        # поля, которые будут выводиться в форму, в порядке указания в списке
        fields = [
            'client_name',
            'client_phone',
            'client_email',
            'date',
            'time',
            # 'hall',
            # 'table',
            'number_persons',
            'comment',
        ]

        # описания полей для отображения в форме
        labels = {
            'client_name': _('Имя'),
            # 'hall': _('Зал'),
            # 'table': _('Столик'),
            'number_persons': _('Количество гостей'),
            'comment': _('Комментарий'),
        }
    #проверка атуальности даты и времени бронирования
    def clean(self):
        cleaned_data = super().clean()
        #получаем введенную дату бронирования
        date = cleaned_data.get("date")
        #получаем введенное время бронирования
        time = cleaned_data.get("time")
        #объединяем дату и время
        date_and_time = datetime.combine(date, time)

        #сравниваем введенные дату и время с текущими датой и временем
        if date_and_time <= datetime.now():
            raise ValidationError(
                "Ошибка. Дата бронирования не может быть раньше текущего времени!"
            )
        return cleaned_data
