from django.urls import path

# импортируем наши представления
from .views import (ApplicationsList, ApplicationDetail, ApplicationCreate)

urlpatterns = [
    # связываем представления с URL-адресами страниц
    path('', ApplicationsList.as_view(), name='apps_list'),
    path('<str:pk>', ApplicationDetail.as_view(), name='app_detail'),
    path('create/', ApplicationCreate.as_view(), name='app_create'),
]
