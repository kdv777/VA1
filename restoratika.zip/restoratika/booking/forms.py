# импорт стандартных форм Джанго
from django import forms
# импорт поля ввода даты
from django.forms import DateInput
# импорт метода для локализации полей формы
from django.utils.translation import gettext_lazy as _

# импорт нашей модели
from .models import Application

# форма для ввода данных о бронировании
class ApplicationForm(forms.ModelForm):
    # поля с проверками минимальной длины, виджетом выбора даты и описанием для отображения в форме
    client_phone = forms.CharField(min_length=11, label='Номер телефона')
    date = forms.DateField(widget=DateInput(attrs={'type': 'date'}), label='Дата')
    time = forms.CharField(min_length=5, label='Время')

    class Meta:
        # наша модель
        model = Application
        # поля, которые будут выводиться в форму, в порядке указания в списке
        fields = [
            'client_name',
            'client_phone',
            'client_email',
            'date',
            'time',
            'hall',
            'table',
            'number_persons',
            'comment',
        ]

        # описания полей для отображения в форме
        labels = {
            'client_name': _('Имя'),
            'client_email': _('Адрес электронной почты'),
            'hall': _('Зал'),
            'table': _('Столик'),
            'number_persons': _('Количество гостей'),
            'comment': _('Комментарий'),
        }
